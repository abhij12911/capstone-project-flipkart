

export const ADD_TO_CART = "addToCart"
export const REMOVE_FROM_CART = "removeFromCart"
export const CART_RESET = "cartReset"